/*
*  Decompression using LZ77 algorithm.
*  Dictionary need not to be taken as input from LZ77 compressor.
*  Dictionary will be automatically and dinamically created at Decompressor side.
*  Input:-   only compressed file in .txt format which compressed using LZ77 compressor
*  Output:-  1) Decompressed file
*                  2) Dynamically created dictionary at decomperssor end (OPTIONAL, only for the sake of understanding)
*/


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define MAX 200

//Structure for node of dictionary
// Dictionary is implemented using singly linklist
struct node
{
    char str[MAX];
    struct node* next;
};
struct node *head=NULL, *last=NULL;


//Function will create the dictionary and return decompressed string
void insert_diction(int idx, char *key)
{
    int count;
    struct node* temp1;
    struct node* temp=(struct node*)malloc(sizeof(struct node));
    if(idx==0){
        strcpy(temp->str,key);
    }
    else{
        temp1=head;

        count=1;
        while(count!=idx){
                temp1=temp1->next;
                if(temp1==NULL){
                    printf("\n\nAn error occur...need to close abnormaly\n\n");
                    exit(0);
                }
                count++;
        }
        strcpy(temp->str,temp1->str);
        if(key[0]!=EOF)
            strcat(temp->str,key);
    }

    if(!head){
        head=temp;
        last=temp;
    }
    else{
        last->next=temp;
        last=temp;
    }
    last->next=NULL;
}


//Function for writing data of dictionary(Singly link list) into file for understanding purpose
void write()
{
    struct node* temp=head;
    FILE *fp_diction;
    int count=1;
    fp_diction=fopen("De_Dictionary.txt","w");
    while(head){
        fprintf(fp_diction,"%d \t %s\n",count,head->str);
        count++;
        temp=head;
        head=head->next;
        free(temp);
    }
    fclose(fp_diction);
}

int main()
{
        FILE *fp_in, *fp_out;
        char key[1];
        int idx;
        printf("\n Hello world \n");
        if(!(fp_in=fopen("compress.txt","r"))){
            printf("\nError in opening the compressed file");
            return 1;
        }
        fp_out=fopen("de_compress.txt","w");
        while(fscanf(fp_in,"%d%c",&idx,&key[0])!=EOF)
        {
                printf("%d\t %c \n",idx,key[0]);
                insert_diction(idx,key);
                fprintf(fp_out,"%s",last->str);
        }
  //      fprintf(fp_out,"%s",last->str);
        fclose(fp_in);
        fclose(fp_out);
        write();
        return 0;
}
