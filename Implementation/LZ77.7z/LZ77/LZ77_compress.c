/*
*  Compression using LZ77 algorithm
*  Input file must not contain any digit
*  All other characters including all special characters are allowed in input file
*  Dictionary need not to be passed to LZ77 decompressor
*  Dictionary will be automatically and dinamically created at Decompressor side.
*
*  Input:-  File to compressed in .txt format following above ristrictions
*  Output:- 1) Compressed file in .txt format
*                2)  Dictionary  (OPTIONAL, only for the sake of understanding)
*/


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 200

//Structure for node of dictionary
// Dictionary is implemented using singly linklist
struct node
{
    char str[MAX];
    struct node *next;
};
struct node *head=NULL, *last=NULL;

//Function for Searching the Dictionary. Linear searching is done
int search(char *str)
{
    int count=1;
    struct node *temp=head;

    while(temp){
        if(strcmp(str,temp->str)==0)
            return count;
        temp=temp->next;
        count++;
        }
        return 0;
}

//Function for inserting into dictionary. That is Apending the node at the end of Singly link list
void insert(char key[MAX])
{
    struct node *temp;
    temp=(struct node *)malloc(sizeof(struct node));
    strcpy(temp->str,key);
    if(!head){
        head=temp;
        last=temp;
    }
    else{
        last->next=temp;
        last=temp;
    }
        last->next=NULL;
}

//Function for writing data of dictionary(Singly link list) into file for understanding purpose
void write()
{
    struct node* temp=head;
    FILE *fp_diction;
    int count=1;
    fp_diction=fopen("Dictionary.txt","w");
    while(head){
        fprintf(fp_diction,"%d \t %s\n",count,head->str);
        count++;
        temp=head;
        head=head->next;
        free(temp);
    }
    fclose(fp_diction);
}

 int main()
 {
    FILE *fp_in, *fp_out;
    char ch[1];                     //Contains a current look ahead character
    char key[MAX];              //Contains String matched at dictionary with current look ahead character appended
    int idx,prev_idx=0,flag;

    printf("\nHello world\n");

    fp_in=fopen("sample.txt","r");              //File to be compressed
    if(!fp_in){
        printf("\nError in opening the source file");
        return 1;
    }
    fp_out=fopen("compress.txt","w");             //Output (Compressed)  file

    flag=1;

    while(1){
        ch[0]=fgetc(fp_in);

        //if(ch[0]==EOF)
            //break;
        if(ch[0]!=EOF)
        {
            if(flag){
                strcpy(key,ch);
                flag=0;
            }
            else
                strcat(key,ch);
        }


            if((idx=search(key))){
                prev_idx=idx;
                if(ch[0]!=EOF)
                    continue;
            }

            fprintf(fp_out,"%d%c",prev_idx,ch[0]);

        //
        printf("look=%c\tkey=%s\n",ch[0],key);
        //
        insert(key);
        prev_idx=0;
        flag=1;

        if(ch[0]==EOF)
            break;

    }

    fclose(fp_in);
    fclose(fp_out);
    write();
    return 0;
 }
